
package project.pkg2;
import java.util.Scanner;
public class Project2 {
    
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
 double A,P,I,N;
    System.out.println("Enter the principal amount");
     P=input.nextDouble();//receive the input
    System.out.println("Enter the annual interest rate:");
    I=input.nextDouble();
    System.out.println("Enter the period:");
    N=input.nextDouble();
    A=P*Math.pow((1+I),N);
    System.out.println("The value of A is "+A);
    
      
       
    }
    
}
